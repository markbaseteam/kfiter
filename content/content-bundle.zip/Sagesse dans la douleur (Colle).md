---
date: 2020-11-08
modified: 2022-08-03
---


> [!NOTE] 
> Essai réalisé comme support à une interrogation orale sur le fragment 278 p257 dans *Le Gai Savoir* de Nietzsche.


### Introduction

Nietzsche, atteint de syphilis, maladie infectieuse très douloureuse, a vécu la souffrance toute sa vie. Enfant, il perd son père et son petit frère, et ses livres ne connaissent le succès qu'après sa mort en 1900. Dans *Le Gai Savoir*, Nietzsche aborde le thème de la douleur, et notamment dans le paragraphe 318 que je vais étudier, intitulé "Sagesse dans la douleur".

Nous nous demanderons en quoi la douleur est intrinsèquement humaine, et même nécessaire à la force de vivre ? Premièrement nous verrons qu'il nous faut apprendre à vivre avec la douleur, puis que cette douleur est de fait une dimension nécessaire de la vie.

### I. Apprendre à vivre avec la douleur

#### La douleur, un être multidimensionnel

Si nous devons apprendre à vivre avec la douleur, celle-ci est d'abord présentée comme un être multidimensionnel par Nietzsche. Prenant l'image d'un homme amené à "disposer les voiles [d'un bateau] de mille manières" pour ne pas sombrer, il prend le vent comme allégorie de la douleur pour un homme subissant la tempête d'un évènement douloureux.

Le fait d'être amené à adapter notre position en fonction du vent, de la douleur qui tombe sur nous, nous fait aussi remarquer son épaisseur, sa profondeur, et en un sens son universalité. On retrouve cette dimensionnalité dans le corpus, quand différents auteurs utilisent le même concept de douleur pour différents évènements.

Nietzsche, malade, perçoit plus distinctement la douleur physique. Hugo est accablé par la douleur associée au deuil et à la mort de sa fille. Alexievitch, au-delà de la douleur physique dont souffrent les malades, met en lumière la douleur du souvenir qui accable les survivants. Mais le même concept de douleur est utilisé pour tous, car finalement toutes ces formes de douleur sont reliées à une forme plus primitive de douleur physique, de la même manière que l'esprit ne peut être séparé du corps.

#### Nietzsche et le stoïcisme : ne pas se laisser emporter par la douleur

Face à cette douleur à multiples facettes, Nietzsche nous invite cependant à nous "gonfler" le moins possible pour ne pas succomber à l'emprise de la douleur. Ainsi, on peut remarquer un parallèle entre la pensée de Nietzsche et le stoïcisme.

Postulant que la réalité est le fruit de notre interprétation des évènements, cette doctrine propose un certain détachement par rapport à ce qui est, et ce que l'on choisit de vivre. En se laissant moins atteindre par la douleur qui nous est infligée, on en ressort plus serein et moins dévasté.

Même s'il cite plusieurs fois le stoïcisme dans Les Contemplations, Le poème 13, livre 4 p80, montre au contraire Hugo dépassé par la douleur de la perte de sa fille. Il énonce qu'il a "bien assez vécu", et conclut : "Ô Seigneur ! ouvrez-moi les portes de la nuit , Afin que je m'en aille et que je disparaisse !". Il semble avoir perdu sa force de vivre.

Mais le livre continuant, Hugo ne meurt pas ce jour-là. On pourrait même se demander si atténuer notre douleur ne nous empêcherait pas d'être "métamorphosé" par celle-ci.

#### Atteindre la sagesse par l'expérience

Ce qui nous amène à considérer l'idée que la sagesse dans la douleur doit être atteinte à travers l'expérience personnelle de celle-ci. Dans "il faut être exercé à disposer les voiles [d'un bateau] de mille manières", la présence du mot "exercé" traduit la nécessité d'une certaine forme d'entraînement. Pour savoir que faire avec la douleur, il faut d'abord en avoir une connaissance personnelle, théorique et pratique.

Le "commandement lancé par le capitaine du navire" à "amener les voiles" est ainsi une représentation d'une conscience expérimentée, le capitaine, sachant comment ordonner à son être la position à adopter face à la douleur.

De même, on peut faire un parallèle avec le poème 18 "Apparition" livre 5 des Contemplations p167 où l'ange allégorie de la douleur de Hugo suite à son expérience du deuil, se transforme. "Et l'ange devint noir et dit : Je suis l'amour". La douleur de Hugo se transforme, ou plutôt révèle sa vraie nature, puisque cette douleur se révèle être l'amour.

### II. La douleur, une dimension nécessaire de la vie

#### Une dimension nécessaire

S'il nous faut apprendre à vivre avec l'être multidimensionnel qu'est la douleur, et en développer une connaissance empirique pour pouvoir la tolérer, il ne nous faut cependant pas oublier le fait que la douleur est avant tout une dimension nécessaire de la vie.

Nietzsche la rappelle dès le début du paragraphe, en précisant que la douleur fait partie d'une "force de conservation de l'espèce de premier ordre". On peut penser à la théorie de l'évolution de Darwin, qui précède Nietzsche de quelques années, dans laquelle peut s'inscrire le concept de douleur. La douleur provoque alors l'instinct de survie de l'organisme, et donc de même provoque chez l'homme non pas seulement l'instinct de survie mais aussi initie en lui la force de vivre.

La douleur se présente donc comme nécessaire à la vie, car elle nous permet de lutter contre la mort. C'est d'ailleurs ainsi que Bichat, anatomiste français du 18ᵉ siècle, définit la vie : "la vie est l'ensemble des fonctions qui résistent à la mort", *Recherches Physiologiques sur la vie et la mort*.

#### Le surhomme et la douleur

Si la douleur permet la conservation de la vie, elle a aussi un sens plus grand pour ceux que Nietzsche appelle les "hommes exceptionnels", pouvant être qualifiés de surhommes.

Chez ces hommes-là, leur architecture pulsionnelle bien développée et ordonnée leur permet d'aller puiser dans la douleur une force "créatrice". Ces êtres de volontés dédaignent le confort, qu'ils ne voient que comme une "espèce de bonheur".

C'est grâce à leur volonté de puissance qu'ils n'interprètent pas seulement la douleur comme une force de conservation de l'espèce, mais comme le moyen ultime d'expression, qui leur offre "leurs instants suprêmes".

#### La douleur permet une renaissance

Mais, si chez Nietsche, Hugo, et Alexievitch, la douleur est omniprésente dans leurs œuvres, tous présentent toutefois la particularité de présenter la douleur comme une force régénératrice

Même si chez Nietzsche sa maladie est extrêmement douloureuse, c'est elle qui l'a forgé et poussé à écrire.

> La douleur est l'ultime libératrice de l'esprit

Après chaque douleur et chaque blessure, il y a la possibilité d'une guérison et d'une renaissance. Le traumatisme de Tchernobyl, même étant irréversible, peut être peu à peu guéri en y faisant face et en se souvenant de ce qui s'est passé. De même, le deuil de la fille de Hugo qu'il qualifiait de "sa muse" se transforme ainsi en force créatrice à travers *Les Contemplations*.

### Conclusion

Pour conclure, c'est parce que la douleur est intrinsèquement liée à la vie qu'apprendre à vivre avec est nécessaire pour développer sa force de vivre. Mais, au-delà du fait de pouvoir la supporter, l'accepter et même la rechercher activement nous approfondit. La douleur se transforme alors en force créatrice, et nous permet de renaître, de nous métamorphoser, de persévérer dans la vie.
