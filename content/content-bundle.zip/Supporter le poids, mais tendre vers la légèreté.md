Le passé est un poids universel au spectre de l’expérience humaine. C’est à travers lui et nos souvenirs associés qu’il nous forme. Deux approches sont généralement mises en opposition pour en parler : l’une est un détachement – je fuis mon passé ; l’autre une rencontre avec celui-ci. Je vais argumenter qu’elles ne sont pas mutuellement exclusives, mais complémentaires.

L’archétype de l’homme rongé par son passé et le fuyant me semble omniprésent dans l’art, et les deux exemples me venant à l’esprit sont _Cowboy Bebop_ et _Extraction_.

![](https://i.imgur.com/5TM63zV.png)

![](https://i.imgur.com/Bl5Ru0N.png)

Spike Spiegel et Tyler Rake cherchent à échapper à leur passé, menant des vies de chasseur de primes et de mercenaire risquées. Alourdis par le poids de ce qui a été, ils se dissocient du présent. "Whatever happens, happens", lâche Spike, où plutôt de son surnom "Swimming Bird", qui représente adéquatement le conflit interne au personnage, entre légèreté de l'oiseau et son embourbement dans l'eau du passé. La métaphore de l'eau comme symbole du passé est également utilisée dans *Extraction*, lors de la scène initiale et des scènes finales, Tyler étant submergé par celui-ci et incapable de revivre normalement.

La résolution, dans les deux œuvres, passe par la confrontation, comme rencontre du passé après sa fuite - qu'il est intéressant de mettre en parallèle avec le phénomène de "fight or flight". C'est *Extraction* qui formule le plus clairement cette résolution : on ne se noie uniquement car l'on reste trop longtemps submergé. Autrement dit, vivre dans le passé et ne pas aller de l'avant est ce qui cause notre perte.

Le caractère tragique de ces deux œuvres est que cette confrontation mène à la mort (apparente) des deux personnages, l'ultime délivrance de leur passé qui les a enchaînés. Spike est survolé d'une flopée de colombes comme à la mort de Julia, et Tyler retombe dans l'eau en miroir au début du film. Il est à noter que leur lieu final est pour tous les deux un lieu de passage, à savoir des marches et un pont, comme s'ils avaient été coupés dans leur élan ascensionnel vers un présent plus léger, allégé du passé.

Il est communément accepté qu'il vaut jeter le passé dans l'abîme pour se projeter avec force dans le futur, ce qu'illustre cette citation de Bachelard :

> Jette dans l'abîme ce que tu as de plus lourd.

En revanche,  ce que nous ont appris ces deux œuvres est que l'on ne peut s'en détacher si l'on ne le rencontre en premier lieu, sinon cela devient une fuite. C'est en ce sens que s'inscrit la dernière phrase de _Cowboy Bebop_, "You're gonna carry thay weight", puisqu'on ne peut dépasser son passé qu'en ayant porté son poids émotionnel préalablement.