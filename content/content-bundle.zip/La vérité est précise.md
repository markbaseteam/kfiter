> [I]f there is some precision, there is some science
>  — Herbert Spencer (1880)

La précision est un prérequis de toute démarche scientifique. Alors, si l'on considère que la science est le moyen le plus systématique d'approcher la vérité, celle-ci nécessite d'être précise.

### Conséquences

Des conseils dénués de précision ne s'adressent qu'à ceux qui n'en ont pas besoin.